const Client = require("../models/client.js");
const { Op } = require("sequelize");

async function findAll() {
  const result = await Client.findAll();
  return result;
}

async function findById(client_id) {
  return await Client.findAll({
    where: {
      client_id: {
        [Op.eq]: client_id
      }
    }
  })
}

async function createClient(client){
  return await Client.create({client_firstname: client.client_firstname, client_lastname: client.client_lastname}, {
    where: {
      client_id: {
        [Op.eq]: client.client_id
      }
    }
  })
}

async function updateClient(client) {
  return await Client.update({client_firstname: client.client_firstname, client_lastname: client.client_lastname}, {
    where: {
      client_id: {
        [Op.eq]: client.client_id
      }
    }
  })
}

async function deleteById(client_id){
  return await Client.destroy({
    where: {
      client_id: {
        [Op.eq]: client_id
      }
    }
  }
  )
}

module.exports = {findAll, findById, createClient, updateClient, deleteById};