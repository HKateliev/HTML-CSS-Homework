const app = require('./config.js');

const clientService = require('../service/client-service.js');

app.get('/clients', (req, res) => {
  clientService.findAll().then(result => {
    res.send(result);
  })
});

app.get('/clients/:id', (req, res) => {
  const id = req.params.id;
  clientService.findById(id).then(result => {
    res.send(result);
  })
});

app.post('/client', (req, res) => {
  const client = req.body;
  clientService.createClient(client).then(result => {
    res.send(result);
  });
})

app.put('/client', (req, res) => {
  const client = req.body;
  clientService.updateClient(client).then(result => {
    res.send(result);
  });
})

app.delete('/clients/:id', (req, res) => {
  const id = req.params.id;
  clientService.deleteById(id).then(result => {
    res.send(result);
  })
});

module.exports = app;